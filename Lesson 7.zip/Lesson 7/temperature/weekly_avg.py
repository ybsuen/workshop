def display_avg(total_temp):
    avg_temp = round((total_temp/7),2)
    print("\n" + "Average temperature for the week:" + str(avg_temp))
    return