from flaskapp import app
from flask import render_template, redirect, url_for
import pandas as pd

@app.route("/")
def index():
    return render_template('index.html')

@app.route("/blogs")
def blogs():
    list = [{'Student': 'David Chan', 'Jan': 90, 'Feb': 85, 'Mar': 88},
        {'Student': 'Peter Lee',  'Jan': 72, 'Feb': 75, 'Mar': 68},
        {'Student': 'John Lui',  'Jan': 60,  'Feb': 80,  'Mar': 100 }]
    # df = pd.read_csv("weekly_hours.csv")
    # list = df.to_dict('records')

    return render_template('blogs.html', entries = list)

@app.route("/about")
def about():
    return render_template('about.html')

@app.route("/post")
def post():
    return render_template('post.html')

@app.route("/contact")
def contact():
    return render_template('contact.html')

@app.route("/dashboard")
def dashboard():
    return render_template('dashboard.html')

@app.route("/signup")
def signup():
    return render_template('signup.html')

################################################################################################################

# ERROR HANDLERS

################################################################################################################

@app.errorhandler(404)
def page_not_found(e):
    return render_template('404.html'), 404
