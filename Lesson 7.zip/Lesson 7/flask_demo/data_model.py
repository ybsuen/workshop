from flask import Flask
from flask_sqlalchemy import SQLAlchemy

app = Flask(__name__)

app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///temperature.db'
db = SQLAlchemy(app)

class Temp(db.Model):
    __tablename__ = 'temp'
    ID = db.Column(db.Integer, primary_key=True)
    day = db.Column(db.String(10))
    high = db.Column(db.Float)
    low = db.Column(db.Float)
    # description = db.Column(db.Text)
    
    def __repr__(self):
        return '<Temp %r>' % self.id
